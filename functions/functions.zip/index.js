const functions = require('firebase-functions');
const admin = require('firebase-admin');
const rp = require('request-promise');
admin.initializeApp();

exports.fotballCompetitions = functions.https.onRequest((req, res) => {

    const options = {
        uri: 'https://api.football-data.org/v1/competitions',
        headers: {
            'X-Auth-Token': '16014d84207e48e7938c2baec0f93333'
        },
        json: true
    }

    return rp(options).then(result => {
        result.forEach(league => {
            admin.firestore().doc(`footballData/competitions/data/${league.id}`).set(league, {merge: true});
        });
        return res.send(result)
    }).catch(err => {
        console.log(err)
        return res.send(err);
    })
});

exports.addFixtures = functions.firestore.document('fotballData/competitions/data/{leagueID}').onCreate((snap, context) => {
    const options = {
        uri: `https://api.football-data.org/v1/competitions/${snap.id}/fixtures?timeFrame=n7`,
        headers: {
            'X-Auth-Token': '16014d84207e48e7938c2baec0f93333'
        },
        json: true
    }
    return rp(options).then(result => {

        let fixtures = result["fixtures"];

        fixtures.forEach(fixture => {

            let competitionID = Number(fixture._links.competition.href.split('/').pop());
            let fixtureID  = Number(fixture._links.self.href.split('/').pop());
            let homeTeamID = Number(fixture._links.homeTeam.href.split('/').pop());
            let awayTeamID = Number(fixture._links.awayTeam.href.split('/').pop());
            //console.log(competitionID, fixtureID, homeTeamID, awayTeamID);

            admin.firestore().doc(`footballData/fixtures/${competitionID}/${fixtureID}`).set({
                competitionID: competitionID,
                fixtureID: fixtureID,
                homeTeam: {
                    id: homeTeamID,
                    name: fixture.homeTeamName
                },
                awayTeam: {
                    id: awayTeamID,
                    name: fixture.awayTeamName
                },
                date: fixture.date,
                status: fixture.status,
                matchday: fixture.matchday,
                result: fixture.result,
            }, {merge: true});
        });
    }).catch(err => {
        console.log(err)
    })
})

exports.getNextFixtures = functions.https.onRequest((req, res) => {
    const options = {
        uri: `https://api.football-data.org/v1/fixtures?timeFrame=n7`,
        headers: {
            'X-Auth-Token': '16014d84207e48e7938c2baec0f93333'
        },
        json: true
    }
    return rp(options).then(result => {
        let fixtures = result["fixtures"];

        for(fixture in fixtures) {
            let ref;

            let competitionID = Number(fixture._links.competition.href.split('/').pop());
            let fixtureID  = Number(fixture._links.self.href.split('/').pop());
            let homeTeamID = Number(fixture._links.homeTeam.href.split('/').pop());
            let awayTeamID = Number(fixture._links.awayTeam.href.split('/').pop());

            if(fixture.status == 'FINISHED') {
                ref = admin.firestore().doc(`footballData/fixtures/finished/${fixtureID}`);
            } else if(fixture.status == 'IN_PLAY') {
                ref = admin.firestore().doc(`footballData/fixtures/live/${fixtureID}`);
            } else if(fixture.status == 'TIMED') {
                ref = admin.firestore().doc(`footballData/fixtures/timed/${fixtureID}`);
            } else {
                ref = admin.firestore().doc(`footballData/fixtures/postponed/${fixtureID}`);
            }

            ref.set({
                competitionID: competitionID,
                fixtureID: fixtureID,
                homeTeam: {
                    id: homeTeamID,
                    name: fixture.homeTeamName
                },
                awayTeam: {
                    id: awayTeamID,
                    name: fixture.awayTeamName
                },
                date: fixture.date,
                status: fixture.status,
                matchday: fixture.matchday,
                result: fixture.result,
            }, {merge: true});
        }
        return res.send(result);
    }).catch(err => {
        console.log(err)
    });
});

exports.getPastFixtures = functions.https.onRequest((req, res) => {
    const options = {
        uri: `https://api.football-data.org/v1/fixtures?timeFrame=p7`,
        headers: {
            'X-Auth-Token': '16014d84207e48e7938c2baec0f93333'
        },
        json: true
    }
    return rp(options).then(result => {
        let fixtures = result["fixtures"];

        for(fixture in fixtures) {
            let ref;

            let competitionID = Number(fixture._links.competition.href.split('/').pop());
            let fixtureID  = Number(fixture._links.self.href.split('/').pop());
            let homeTeamID = Number(fixture._links.homeTeam.href.split('/').pop());
            let awayTeamID = Number(fixture._links.awayTeam.href.split('/').pop());

            if(fixture.status == 'FINISHED') {
                ref = admin.firestore().doc(`footballData/fixtures/finished/${fixtureID}`);
            } else if(fixture.status == 'IN_PLAY') {
                ref = admin.firestore().doc(`footballData/fixtures/live/${fixtureID}`);
            } else if(fixture.status == 'TIMED') {
                ref = admin.firestore().doc(`footballData/fixtures/timed/${fixtureID}`);
            } else {
                ref = admin.firestore().doc(`footballData/fixtures/postponed/${fixtureID}`);
            }

            ref.set({
                competitionID: competitionID,
                fixtureID: fixtureID,
                homeTeam: {
                    id: homeTeamID,
                    name: fixture.homeTeamName
                },
                awayTeam: {
                    id: awayTeamID,
                    name: fixture.awayTeamName
                },
                date: fixture.date,
                status: fixture.status,
                matchday: fixture.matchday,
                result: fixture.result,
            }, {merge: true});
        }
        return res.send(result);
    }).catch(err => {
        console.log(err)
    });
});

/* exports.getAllFixtures = functions.https.onRequest((req, res) => {
    const options = {
        uri: `https://api.football-data.org/v1/fixtures`,
        headers: {
            'X-Auth-Token': '16014d84207e48e7938c2baec0f93333'
        },
        json: true
    }
    return rp(options).then(result => {
        let fixtures = result["fixtures"];

        fixtures.forEach(fixture => {

            let competitionID = Number(fixture._links.competition.href.split('/').pop());
            let fixtureID  = Number(fixture._links.self.href.split('/').pop());
            let homeTeamID = Number(fixture._links.homeTeam.href.split('/').pop());
            let awayTeamID = Number(fixture._links.awayTeam.href.split('/').pop());
            //console.log(competitionID, fixtureID, homeTeamID, awayTeamID);

            admin.firestore().doc(`fotballData/fixtures/${competitionID}/${fixtureID}`).set({
                competitionID: competitionID,
                fixtureID: fixtureID,
                homeTeam: {
                    id: homeTeamID,
                    name: fixture.homeTeamName
                },
                awayTeam: {
                    id: awayTeamID,
                    name: fixture.awayTeamName
                },
                date: fixture.date,
                status: fixture.status,
                matchday: fixture.matchday,
                result: fixture.result,
            }, {merge: true});
        });
        return res.send(result);
    }).catch(err => {
        console.log(err)
    });
});
 */